export default {
    DOMAIN: 'pizza4242.auth0.com',
    CLIENT_ID: 'e83X7PA83UzU52zLuSwMWfuqdxXAS04U',
    CLIENT_SECRET: 'juEpK0aAFKhI8EL9JuMq5waxZniLCan8LtdBUHoHpcKA6TYyG30MW0RAotwqz1K8',
    // CALLBACK_URL: 'http://localhost:4200/callback',
    CALLBACK_URL: 'https://pizza4242.herokuapp.com/callback',
    AUTH0MANAGEAPI_CLIENT_ID: 'WxdMlG8zMV2A50kJbhN3hcDUVymPLS9s',
    AUTH0MANAGEApI_CLIENT_SECRET: 'O4qnZKr3C4cb6q4Pjsw2oHbLefIOmTMmfFGoEdLCowNKUIt3y_48Vu8e5fdhRmzx'
};
